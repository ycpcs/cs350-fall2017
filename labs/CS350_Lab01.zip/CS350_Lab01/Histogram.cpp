#include <iostream>
#include "Histogram.h"

Histogram::Histogram(int numBuckets)
{
    // TODO: create an array of int elements,
    // assign a pointer to it to the int* field
}

Histogram::~Histogram()
{
    // TODO: use the delete[] operator to de-allocate
    // the array of ints
}

// TODO: define the other methods
